import json
import os
import smtplib
from email.message import EmailMessage
from html import escape

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from openai import OpenAI

load_dotenv()

app = Flask(__name__)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

TRAINER_EMAIL = os.getenv("TRAINER_EMAIL", "").strip()


# ---------- AI analysis (your original logic) ----------
def analyse_feedback(feedback):
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is not set in Replit Secrets or .env")
    prompt = f"""
    Analyse the following student's feedback.

    Feedback: {feedback}

    Return the result in JSON format with these fields:

    1. sentiment
    2. key_points
    3. suggestion

    Example:
    {{
        "sentiment": "Positive",
        "key_points": ["Good teaching"],
        "suggestion": "Include more real-world projects"
    }}
    """

    response = client.chat.completions.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        messages=[
            {
                "role": "system",
                "content": "You are a student feedback analyser. Return only valid JSON with sentiment, key_points (array), and suggestion.",
            },
            {"role": "user", "content": prompt},
        ],
        response_format={"type": "json_object"},
        temperature=0.2,
    )

    content = response.choices[0].message.content or "{}"
    data = json.loads(content)

    # Normalise the shape so the UI and email never break
    key_points = data.get("key_points", [])
    if isinstance(key_points, str):
        key_points = [key_points]
    return {
        "sentiment": str(data.get("sentiment", "Unknown")),
        "key_points": [str(p) for p in key_points],
        "suggestion": str(data.get("suggestion", "")),
    }


# ---------- Email to trainer ----------
def send_to_trainer(student, result):
    host = os.getenv("SMTP_HOST", "smtp.gmail.com")
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")

    if not user or not password:
        raise RuntimeError("SMTP_USER / SMTP_PASSWORD are not set in .env")
    if not TRAINER_EMAIL:
        raise RuntimeError("TRAINER_EMAIL is not set in .env")

    points_text = "\n".join(f"  - {p}" for p in result["key_points"])
    text = f"""New student feedback

Student : {student['name']} ({student['email']})
Course  : {student['course']}
Rating  : {student['rating']}/5

Feedback:
{student['feedback']}

--- Analysis ---
Sentiment : {result['sentiment']}

Key points:
{points_text}

Suggestion:
{result['suggestion']}
"""

    points_html = "".join(f"<li>{escape(p)}</li>" for p in result["key_points"])
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:560px;color:#1b2430">
      <h2 style="margin:0 0 4px">New student feedback</h2>
      <p style="margin:0 0 16px;color:#5b6675">
        {escape(student['name'])} ({escape(student['email'])}) &middot;
        {escape(student['course'])} &middot; {escape(str(student['rating']))}/5
      </p>
      <blockquote style="margin:0 0 20px;padding:10px 14px;background:#f3f5f8;border-left:3px solid #1f5fbf">
        {escape(student['feedback'])}
      </blockquote>
      <p><strong>Sentiment:</strong> {escape(result['sentiment'])}</p>
      <p style="margin-bottom:4px"><strong>Key points</strong></p>
      <ul style="margin-top:0">{points_html}</ul>
      <p><strong>Suggestion:</strong> {escape(result['suggestion'])}</p>
    </div>
    """

    msg = EmailMessage()
    msg["Subject"] = f"Student feedback: {student['name']} ({result['sentiment']})"
    msg["From"] = user
    msg["To"] = TRAINER_EMAIL
    msg["Reply-To"] = student["email"]
    msg.set_content(text)
    msg.add_alternative(html, subtype="html")

    with smtplib.SMTP(host, port, timeout=20) as server:
        server.starttls()
        server.login(user, password)
        server.send_message(msg)


# ---------- Routes ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json(silent=True) or {}
    student = {
        "name": str(data.get("name", "")).strip(),
        "email": str(data.get("email", "")).strip(),
        "course": str(data.get("course", "")).strip(),
        "rating": str(data.get("rating", "")).strip(),
        "feedback": str(data.get("feedback", "")).strip(),
    }

    missing = [k for k in ("name", "email", "course", "rating", "feedback") if not student[k]]
    if missing:
        return jsonify(error=f"Please fill in: {', '.join(missing)}."), 400

    try:
        result = analyse_feedback(student["feedback"])
    except Exception as e:
        app.logger.exception("Analysis failed")
        return jsonify(error="Could not analyse the feedback. Check your OPENAI_API_KEY in Replit Secrets and try again."), 502

    # The analysis is still shown even if the email fails
    email_sent, email_error = True, None
    try:
        send_to_trainer(student, result)
    except Exception as e:
        app.logger.exception("Email failed")
        email_sent, email_error = False, str(e)

    return jsonify(result=result, email_sent=email_sent, email_error=email_error,
                   trainer=TRAINER_EMAIL)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)