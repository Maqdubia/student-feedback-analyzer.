# Student Feedback Analyzer — Lavender Edition (OpenAI)

## Run on Replit
1. Create a Python Repl.
2. Upload this ZIP and extract it. Open the extracted project folder.
3. In Replit Secrets (lock icon), add the variables listed below.
4. In Shell, run `pip install -r requirements.txt`.
5. Run `python app.py` (or set the Run command to `python app.py`).

## Required Replit Secrets
- `OPENAI_API_KEY`: a NEW key created at https://platform.openai.com/api-keys
- `TRAINER_EMAIL`: the trainer's destination email address
- `SMTP_USER`: your Gmail address used to send the notification
- `SMTP_PASSWORD`: a Google App Password, not your normal Gmail password

Optional:
- `OPENAI_MODEL`: defaults to `gpt-4o-mini`
- `SMTP_HOST`: defaults to `smtp.gmail.com`
- `SMTP_PORT`: defaults to `587`

## Gmail setup
Enable 2-Step Verification on your Google account, then create an App Password at https://myaccount.google.com/apppasswords. Use that app password as `SMTP_PASSWORD`.

## Security
Never put API keys or Gmail passwords in source code, screenshots, or a committed `.env` file. The API key previously pasted into chat should be revoked; create a replacement and add only the replacement to Replit Secrets.

The app uses Flask, OpenAI's Chat Completions API with JSON output, and Gmail SMTP.
