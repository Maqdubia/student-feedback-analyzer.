from openai import OpenAI
import json
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Initialize Groq client using OpenAI-compatible library
client = OpenAI(
    api_key=os.getenv("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1"
)


def analyse_feedback(feedback):

    prompt = f"""
    Analyse the following student's feedback.

    Feedback: {feedback}

    Return the result in JSON format with these fields:

    1. sentiment
    2. key_points
    3. suggestion

    Example:
    {{
        "sentiment": "Positive",
        "key_points": ["Good teaching"],
        "suggestion": "Include more real-world projects"
    }}
    """

    response = client.chat.completions.create(

        model="openai/gpt-oss-20b",

        messages=[
            {
                "role": "system",
                "content": "You are a student feedback analyser. Always return valid JSON."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],

        response_format={
            "type": "json_object"
        }

    )

    # Extract AI response
    result = response.choices[0].message.content

    # Convert JSON string into Python dictionary
    return json.loads(result)


# User input
feedback = "The trainer explains concepts clearly. The practical sessions are very useful, but more real-world projects should be included."

# Analyse feedback
result = analyse_feedback(feedback)

# Display result
print("\nStudent Feedback Analysis:")
print(json.dumps(result, indent=4))
